﻿namespace $rootnamespace$
{
    PipelineRBuilder
}
