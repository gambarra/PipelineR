﻿namespace $rootnamespace$
{
    PipelineRStep
}
